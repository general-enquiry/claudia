<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <script type="text/javascript" src="<?= $site->url() ?>/assets/js/jquery.js"></script>
    <script type="text/javascript" src="<?= $site->url() ?>/assets/js/main.js"></script>
    <link rel="stylesheet" href="<?= $site->url() ?>/assets/css/style.css?v=0.2">

    <title></title>
  </head>
  <body>
    <header>
      <div class="archive-header">
        <span class="project">PROJECT</span>
        <span class="title">TITLE</span>
        <span class="category">CATEGORY</span>
        <span class="date">DATE</span>
      </div>
      <h1 class="footer-trigger">CLAUDIA LAU</h1>
    </header>

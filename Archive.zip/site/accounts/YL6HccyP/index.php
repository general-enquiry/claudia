<?php

return [
    'email' => 'mail@general-enquiry.com',
    'language' => 'en',
    'name' => 'Alex Margetic',
    'role' => 'admin'
];
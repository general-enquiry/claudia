<?php

return [
    'email' => 'hi@public-office.info',
    'language' => 'en',
    'name' => '',
    'role' => 'admin'
];
<?php

return array(
	'pagetable.rowsPerPage'  => 'Rodomi puslapiai',
	'pagetable.of'           => 'iš',
	'pagetable.all'          => 'Visi',
	'pagetable.filter-pages' => 'Filtruoti puslapius…',
	'pagetable.reset'        => 'Atšaukti',
);

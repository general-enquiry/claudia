<?php

return array(
	'pagetable.rowsPerPage'  => 'Gösterilen sayfalar',
	'pagetable.of'           => 'toplam',
	'pagetable.all'          => 'Tümü',
	'pagetable.filter-pages' => 'Sayfaları filtrele..',
	'pagetable.reset'        => 'Sıfırla',
);

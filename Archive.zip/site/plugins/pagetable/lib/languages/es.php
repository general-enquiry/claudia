<?php

return array(
	'pagetable.rowsPerPage'  => 'Productos por página',
	'pagetable.of'           => 'de',
	'pagetable.all'          => 'Todos',
	'pagetable.filter-pages' => 'Filtrar páginas…',
	'pagetable.reset'        => 'Reiniciar',
);

import PageTable from './PageTable.vue'

panel.plugin('sylvainjule/pagetable', {
    sections: {
        'pagetable': PageTable,
    },
});
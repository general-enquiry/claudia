<?php
  return [
    'debug' => true,
    'panel' => [
      'css' => 'assets/css/panel.css'
    ]
  ];
?>
